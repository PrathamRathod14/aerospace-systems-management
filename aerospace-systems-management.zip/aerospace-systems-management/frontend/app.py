from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/mbse')
def mbse():
    return render_template('mbse.html')

@app.route('/digital-twin')
def digital_twin():
    return render_template('digital_twin.html')

@app.route('/predictive-maintenance')
def predictive_maintenance():
    return render_template('predictive_maintenance.html')

@app.route('/collaboration')
def collaboration():
    return render_template('collaboration.html')

if __name__ == '__main__':
    app.run(debug=True)
