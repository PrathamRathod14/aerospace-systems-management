import numpy as np
from sklearn.linear_model import LinearRegression

# Dummy data for demonstration
def load_data():
    X = np.array([[1, 2], [2, 4], [3, 6], [4, 8], [5, 10]])
    y = np.array([2, 4, 6, 8, 10])
    return X, y

# Train a simple linear regression model
def train_model():
    X, y = load_data()
    model = LinearRegression()
    model.fit(X, y)
    return model

# Predict based on input data
def predict(model, input_data):
    return model.predict(input_data)

if __name__ == "__main__":
    model = train_model()
    test_data = np.array([[6, 12]])
    prediction = predict(model, test_data)
    print(f"Predicted value: {prediction}")
