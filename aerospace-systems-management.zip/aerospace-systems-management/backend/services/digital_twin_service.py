def get_digital_twin_data():
    # Mocked digital twin data
    data = {
        "system_name": "Aerospace Engine X",
        "status": "Operational",
        "last_check": "2024-09-14",
        "temperature": "85°C",
        "vibration_level": "Normal"
    }
    return data
