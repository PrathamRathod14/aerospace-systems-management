def get_mbse_data():
    # Mocked MBSE data
    data = {
        "model_name": "Aerospace Engine X Model",
        "components": [
            {"name": "Engine", "status": "Integrated"},
            {"name": "Fuel System", "status": "Pending"},
            {"name": "Control System", "status": "Operational"}
        ]
    }
    return data
