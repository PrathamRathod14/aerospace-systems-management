from flask import Flask
from services.mbse_service import get_mbse_data
from services.digital_twin_service import get_digital_twin_data

app = Flask(__name__)

@app.route('/')
def index():
    return "Aerospace Systems Management API is running."

@app.route('/mbse')
def mbse():
    data = get_mbse_data()
    return {"mbse_data": data}

@app.route('/digital-twin')
def digital_twin():
    data = get_digital_twin_data()
    return {"digital_twin_data": data}

if __name__ == '__main__':
    app.run(debug=True)
