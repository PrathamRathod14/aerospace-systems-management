from sqlalchemy import Column, Integer, String, Float
from backend.db.database_setup import Base

# System performance model
class SystemPerformance(Base):
    __tablename__ = 'system_performance'
    id = Column(Integer, primary_key=True)
    system_name = Column(String)
    uptime_percentage = Column(Float)
    maintenance_needed = Column(Float)
