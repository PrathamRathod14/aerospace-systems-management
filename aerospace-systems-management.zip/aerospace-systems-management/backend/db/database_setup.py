from sqlalchemy import create_engine, Column, Integer, String, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

Base = declarative_base()

# Define the system performance data model
class SystemPerformance(Base):
    __tablename__ = 'system_performance'
    id = Column(Integer, primary_key=True)
    system_name = Column(String)
    uptime_percentage = Column(Float)
    maintenance_needed = Column(Float)

# Database setup function with MySQL credentials
def setup_database():
    # Replace with your actual MySQL credentials
    DATABASE_URI = 'mysql+mysqlclient://root:Pratham1@localhost/aerospace_db'
    
    engine = create_engine(DATABASE_URI)
    Base.metadata.create_all(engine)
    return engine

# Initialize database session
def get_session(engine):
    Session = sessionmaker(bind=engine)
    return Session()

if __name__ == "__main__":
    engine = setup_database()
    session = get_session(engine)
    print("Database setup complete.")
